
import pandas as pd
from pathlib import Path

# 1. 把 5 个 fold 的 csv 读进来
files = [f'deepDDI_class_metrics_fold_{i}.csv' for i in range(5)]
print(files)
dfs = [pd.read_csv(f) for f in files if Path(f).is_file()]

if not dfs:
    raise FileNotFoundError('未找到任何 fold 文件，请确认文件名及路径！')

# 2. 合并后按 Class 分组计算均值和标准差
mean_df = (
    pd.concat(dfs, ignore_index=True)
      .groupby('Class', as_index=False)
      .agg(
          AUCPR=('AUCPR', 'mean'),
          F1=('F1', 'mean'),
          AUCPR_std=('AUCPR', 'std'),
          F1_std=('F1', 'std')
      )
      .round(4)
)

mean_df['Class'] = mean_df['Class'] + 1

# 3. 保存结果
mean_df.to_csv('deepDDI_mean_metrics.csv', index=False, float_format='%.4f')
print('已生成 Deng_mean_metrics.csv：')
print(mean_df.head())
